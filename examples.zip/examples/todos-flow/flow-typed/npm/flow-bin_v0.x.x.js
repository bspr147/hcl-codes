// flow-typed signature: c1ad626d56cf52dd45be9c4432486e9e
// flow-typed version: c6154227d1/flow-bin_v0.x.x/flow_>=v0.25.x <=v0.103.x

declare module "flow-bin" {
  declare module.exports: string;
}
