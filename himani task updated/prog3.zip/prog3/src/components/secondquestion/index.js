import secondquestion from "./secondquestion"
export default secondquestion;
