import React, {Component} from 'react';
import './secondquestion.scss'
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as secondquestionActions from "../../store/secondquestion/actions";
export default class SecondQuestion extends Component {
  constructor(props) {  
    super(props);  
    if(localStorage.getItem("qual") !==undefined) {
      this.state = {  
        qualification: localStorage.getItem("qual"),
        //city : localStorage.getItem("city"),
        //state : localStorage.getItem("st")
      };  
    } else {
      this.state = {  
        qualification: '',
    //    city : '',
      //  state : ''
      };    
    }
    
}  
nextButton = () => {
  // alert(this.state.firstName);
 // alert(this.state.qualification);
   localStorage.setItem("qual",this.state.qualification);
 //  localStorage.setItem("city",this.state.city);
  // localStorage.setItem("st",this.state.state);
   this.props.history.push('/thirdq')
 }

 prevButton = () => {
  this.props.history.push('/firstq')
}
changeQualification(event) {  
    this.setState({  
        qualification: event.target.value
    });  
}

render() {  
    return (  
        <div>  
            <h2>Qualification Details</h2>
            <table border="3">
              <tr>
                <th>
                <label htmlFor="Qualification">Qualification </label>
                </th>
                <td>
                <textarea value={this.state.qualification} 
                  onChange={this.changeQualification.bind(this)} cols={40} rows={10} />
                </td>
              </tr>
                <tr>
                  <th colspan="2">
                  <input type="button" onClick={this.prevButton} value="Previous Question" />
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input type="button" onClick={this.nextButton} value="Next Question" />
                  </th>
                </tr>
            </table>  
        </div>  
    );
  }
  }
// export default connect(
//     ({ secondquestion }) => ({ ...secondquestion }),
//     dispatch => bindActionCreators({ ...secondquestionActions }, dispatch)
//   )( secondquestion );