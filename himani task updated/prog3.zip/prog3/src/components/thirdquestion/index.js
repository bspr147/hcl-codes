import thirdquestion from "./thirdquestion"
export default thirdquestion;
