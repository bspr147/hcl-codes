import firstquestion from "./firstquestion"
export default firstquestion;
